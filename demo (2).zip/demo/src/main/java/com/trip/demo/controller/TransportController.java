package com.trip.demo.controller;


import com.trip.demo.Model.Transport;
import com.trip.demo.services.TransportServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@RestController
@RequestMapping("/transport")
public class TransportController {
    @Autowired
    private TransportServices transportService;


    @GetMapping
    public List<Transport> getAllTransports() {
        return transportService.getAllTransports();
    }

    @GetMapping("/{id}")
    public Transport getTransportById(@PathVariable("id") Long id) {
        Optional<Transport> optionalTransport = transportService.getTransportById(id);
        return optionalTransport.orElseThrow(() -> new NotFoundException("Transport not found"));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Transport createTransport(@RequestBody Transport transport) {
        return transportService.createTransport(transport);
    }

    @PutMapping
    public Transport updateTransport(@RequestBody Transport updatedTransport) {
        Optional<Transport> optionalTransport = transportService.updateTransport(updatedTransport);
        return optionalTransport.orElseThrow(() -> new NotFoundException("Transport not found"));
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteTransport(@PathVariable("id") Long id) {
        boolean deleted = transportService.deleteTransport(id);
        if (!deleted) {
            throw new NotFoundException("Transport not found");
        }
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    public static class NotFoundException extends RuntimeException {
        public NotFoundException(String message) {
            super(message);
        }
    }
}
