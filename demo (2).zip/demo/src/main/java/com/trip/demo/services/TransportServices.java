package com.trip.demo.services;

import com.trip.demo.Model.Transport;
import com.trip.demo.repository.TransportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TransportServices {
    @Autowired
    private  TransportRepository transportRepository;

    public List<Transport> getAllTransports() {
        return transportRepository.findAll();
    }

    public Optional<Transport> getTransportById(Long id) {
        return transportRepository.findById(id);
    }

    public Transport createTransport(Transport transport) {
        return transportRepository.save(transport);
    }

    public Optional<Transport> updateTransport(Transport transport) {
        if (transportRepository.existsById(transport.getShipperId())) {
            return Optional.of(transportRepository.save(transport));
        } else {
            return Optional.empty();
        }
    }

    public boolean deleteTransport(Long id) {
        if (transportRepository.existsById(id)) {
            transportRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }
}
