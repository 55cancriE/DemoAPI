package com.trip.demo.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name="TransportProfile")
public class Transport {
    @Id

    long shipperId;
    String loadingPoint;
    String unloadingPoint;
    String productType;
    String truckType;
    long noOfTrucks;
    long weight;
    String optionalComment;
    Date date;
}
